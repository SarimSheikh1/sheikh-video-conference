const router=require('express').Router(); const db=require('../config/database'); const {requireAuth}=require('../middleware/authMiddleware');
router.use(requireAuth);
router.get('/me',(req,res)=>res.json({user:req.user}));
router.get('/',(req,res)=>{const q=`%${(req.query.q||'').trim()}%`;const users=db.prepare('SELECT id,name,username,email,profile_image,bio,status FROM users WHERE id != ? AND (name LIKE ? OR username LIKE ? OR email LIKE ?) LIMIT 50').all(req.user.id,q,q,q);res.json({users})});
router.put('/me',(req,res)=>{const {name,bio,status}=req.body;db.prepare('UPDATE users SET name=COALESCE(?,name),bio=COALESCE(?,bio),status=COALESCE(?,status) WHERE id=?').run(name,bio,status,req.user.id);res.json({user:db.prepare('SELECT id,name,username,email,profile_image,bio,status FROM users WHERE id=?').get(req.user.id)})});
module.exports=router;
